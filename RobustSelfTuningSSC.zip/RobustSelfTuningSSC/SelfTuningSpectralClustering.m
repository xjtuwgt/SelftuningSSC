%--------------------------------------------------------------------------
% CKSym: NxN adjacency matrix
% cK: number of groups for searching
% groups: N-dimensional vector containing the memberships of the N points 
% to the n groups obtained by spectral clustering
% optK: the estimated cluster number
% runtime: cluster number estimation time
%--------------------------------------------------------------------------
% Copyright @ G.T. Wang, 2017
%--------------------------------------------------------------------------

function [groups,optK,runtime] = SelfTuningSpectralClustering(CKSym,cK)

warning off;
N = size(CKSym,1);
% Normalized spectral clustering according to Ng & Jordan & Weiss
% using Normalized Symmetric Laplacian L = I - D^{-1/2} W D^{-1/2}
DN = diag( 1./sqrt(sum(CKSym)+eps) );
LapN = speye(N) - DN * CKSym * DN;
[~,~,vN] = svd(LapN);
[optK,runtime] = OptimalKSelectionForSSC( vN, cK);
[~,groups] = DensityBasedSpectralClustering(vN, optK);
