function [Data,gTruth] = SyntheticDataGeneration(D, N, K, d, randSeed)
%Generate the synthetic data
%D: dimension of ambient space
%N: number of samples in each subspace
%K: number of subspaces
%d: intrinsic dimension of each subspace%M
%Data = zeros(D, N*K);
gTruth = zeros(1, N*K);

rng(randSeed)
%The set of Basis of all subspaces, with dimension of each subspace d
% A = rand(D, D);
% [Q, ~] = qr(A);
Basis = rand([D, d, K]);
rng(randSeed+1)
% for i = 1:K
%     basisIndexesi = randperm(D,d);
%     Basis(:,:,i) = Q(:,basisIndexesi);
% end
% 
% rng(randSeed+2)
Coef = rand([d, N, K]);

Data = []; 
for k = 1:K
    Basisk = Basis(:,:,k);
    Coefk = Coef(:,:,k);
    Dk = Basisk*Coefk;
    Data = [Data,Dk];
    gTruth(((k-1)*N+1):(k*N)) = k; 
end

normBase = sqrt(sum(Data.^2)+eps);
for i = 1:length(normBase)
    Data(:,i) = Data(:,i)./normBase(i);
end

%save Data M
%disp(Basis);

end






