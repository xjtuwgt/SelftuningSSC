function [ maxg, gamaArray,distTime,deltatime] = maxDensityGapforSSC(vN,K)
%UNTITLED2 Summary of this function goes here
%   vN: all vectors
%   k: number of clusters
%   gamaArray: centraility coefficients
%   maxg: max gap computation
%-------------------
N = size(vN,2);
kerN = vN(:,N-K+1:N);
normN = sum(kerN .^2, 2) .^.5;
kerNS = bsxfun(@rdivide, kerN, normN + eps);
t1 = cputime;
distMatrix = squareform(pdist(kerNS))+eps;
t2 = cputime;
distTime = t2 - t1;

t1 = cputime;
M = ceil(sqrt(N));
sortDistMat = sort(distMatrix);
rhoArray = M./mean(sortDistMat([2:(M+1)],:));

maxd=max(max(distMatrix));
[~,ordrho]=sort(rhoArray,'descend');
deltaArray = zeros(1,N);
deltaArray(ordrho(1))=-1;


for ii=2:N
   deltaArray(ordrho(ii))=maxd;
   indexesii = ordrho(1:ii-1);
   minDist = min(distMatrix(ordrho(ii),indexesii));
   if minDist < deltaArray(ordrho(ii))
       deltaArray(ordrho(ii)) = minDist;
   end
end

deltaArray(ordrho(1))=max(deltaArray(:));
gamaArray = rhoArray.*deltaArray;
[maxg] = maxgap( gamaArray, K);
t2 =  cputime;
deltatime = t2-t1;
end

