function [ optK, runtime] = OptimalKSelection( vN, cK)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
gapArray = zeros(cK,1);
N = size(vN,1);
% tempMatrix = zeros(N, cK);
t1 = 0;
t2 = 0;
gammaMatrix = zeros(cK,N);
for K = 2:cK
    [ maxg, gammaArray , distTime,deltatime] = maxDensityGapSpeedUp(vN,K);
    gammaMatrix(K,:) = gammaArray;
   %tempMatrix(:,K-1) = (gammaArray/max(gammaArray));
   t1 = t1 + distTime;
   t2 = t2 + deltatime;
    gapArray(K) = maxg;
end
runtime = 2*t1/cK + t2;
% sMatrix = sort(tempMatrix);
% indexes = 140:150;
% L = length(indexes);
% 
% plot(sMatrix(indexes,1))
% hold on
% plot(sMatrix(indexes,2))
% plot(sMatrix(indexes,3))
% plot(sMatrix(indexes,4))

% plot(sMatrix(indexes,1), ones(L,1),'.','markersize',15)
% hold on
% plot(sMatrix(indexes,2),ones(L,1)+1,'.','markersize',15)
% plot(sMatrix(indexes,3),ones(L,1)+2,'.','markersize',15)
% plot(sMatrix(indexes,4),ones(L,1)+3,'.','markersize',15)
% 
% legend({'2','3','4','5'})


[maxV,optK] = max(gapArray);

if cK > 5%%Avoid Avoid falling into smaller clusters when the number of clusters is large on noise data
    counts = zeros(1,cK);
    ratios = zeros(1,cK);
    for i = optK+1:cK-1
        tempArrayi = gapArray(i) - gapArray((i+1):cK);
        if isempty(find(tempArrayi < 0)) %#ok<EFIND>
            counts(i) = length(tempArrayi);
            ratios(i) = sum(gapArray((i+1):cK))/sum(gapArray);
        end
    end
    
    [~,maxK] = max(counts);

    if (maxK > optK +1) && (gapArray(maxK) > 0.2*maxV) && (gapArray(maxK) > gapArray(maxK-1))
        optK = maxK;
        maxV = gapArray(optK);
    end
end

% if cK > 10
%     gapArray = gapArray;
%     [sortV,sortIdx] = sort(gapArray([(optK+1):cK]),'descend');
%     for i = 1:length(sortIdx)
%         sortIdi = sortIdx(i);
%         origIdi = optK+sortIdi;
%         tempVi = gapArray(origIdi);
%         if tempVi > 0.2*maxV
%             for j = (origIdi+1):cK
%                 if gapArray(j) > tempVi
%                     break;
%                 end
%             end
%             
%             if j == cK
%                 if origIdi > optK + 1
%                     optK = origIdi;
%                     maxV = gapArray(optK);
%                     break;
%                 else
%                     break;
%                 end
%             end
%             
%         end
%         
% %         ratio = sum(gapArray([(optK+sortIdi + 1):cK]))/sum(gapArray);
% %         len = cK - (optK+sortIdi + 1);
% %         if ratio < 0.1 && (len > 5) && sortV(i) > 0.2*maxV && sortIdi > 2
% %             optK = optK+sortIdi;
% %             maxV = gapArray(optK);
% %             break;
% %         end
%     end    
% end

% [optKSet] = OutwardStatTestCenterDetection(gapArray, 0.05);
% 
% if length(optKSet == 2)
% else
%     optK = max(optKSet);
%     maxV = gapArray()
% end

% %===========
% if cK > 10
%     gapArray = gapArray + eps;
%     [sortV,sortIdx] = sort(gapArray([(optK+1):cK]),'descend');
%     for i = 1:length(sortIdx)
%         sortIdi = sortIdx(i);
%         ratio = sum(gapArray([(optK+sortIdi + 1):cK]))/sum(gapArray);
%         len = cK - (optK+sortIdi + 1);
%         if ratio < 0.1 && (len > 5) && sortV(i) > 0.2*maxV && sortIdi > 2
%             optK = optK+sortIdi;
%             maxV = gapArray(optK);
%             break;
%         end
%     end    
% end
%===========
% if cK > 10% Avoid falling into 2 or 3 clusters when the number of clusters is large
%     gapArray = gapArray + eps;
%     [sortV,sortIdx] = sort(gapArray([(optK+1):cK]),'descend');
%     % if (sortV(1)/maxV > 0.5)
%     for i = 1:length(sortIdx)
%         sortIdi = sortIdx(i);
%         ratio = sum(gapArray([(optK+sortIdi + 1):cK]))/sum(gapArray);
%         len = cK - (optK+sortIdi + 1);
%         if ratio < 0.1 && (len > 5) && sortV(i) > 0.1*maxV && sortIdi > 2
%             optK = optK+sortIdi;
%             maxV = gapArray(optK);
%             break;
%         end
%     end
%     % end
%     
% % % %     %     [ndMax,ndIdex] = max(gapArray([(optK+1):cK]));
% % % %     %     if (ndMax > maxV*(1 - 0.05))|| ((sum(gapArray([(optK+ndIdex+1):cK]))/sum(gapArray) < 0.05) && ((cK - optK - ndIdex) > 5))
% % % %     %         optK = optK + ndIdex;
% % % %     %         maxV = gapArray(optK);
% % % %     %     end
% % % %     %     for k = cK:-1:(optK+1)
% % % %     %         if (5*sum(gapArray(k:cK)) < gapArray(k-1) && ((cK - k)>5) && gapArray(k-1) > 1/(5*cK))||(gapArray(k-1) > (1-0.05)*maxV)
% % % %     %             break;
% % % %     %         end
% % % %     %     end
%     
%     
%     
% end
% indexes = find(gapArray > (maxV-0.5/cK));
% if isempty(indexes)
%     return;
% else
%     optK = indexes(length(indexes));
%     maxV = gapArray(indexes(length(indexes)));
% end

plot(gapArray,'k')
hold on
plot(gapArray,'ko','markersize',8,'markerfacecolor','k')

plot(optK, maxV, 'ro','markersize',10,'markerfacecolor','r')
plot(optK, maxV, 'ko','markersize',5,'markerfacecolor','k')
xlim([2,cK])

set(gca,'fontsize',16)

end

