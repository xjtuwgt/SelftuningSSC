%-----------------------------------------------------------
% vN: vectors of the normalized laplacian graph matrix
% cK: the search space [2,cK]
% optK: estimated cluster number
%-----------------------------------------------------------
function [ optK, runtime] = OptimalKSelectionForSSC( vN, cK)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%% vN: vectors of normalized laplacian graph
%% cK: search space [2, cK]
gapArray = zeros(cK,1);
N = size(vN,1);
t1 = 0;
t2 = 0;
gammaMatrix = zeros(cK,N);
for K = 2:cK
    [ maxg, gammaArray , distTime,deltatime] = maxDensityGapForSSC(vN,K);
    gammaMatrix(K,:) = gammaArray;
   %tempMatrix(:,K-1) = (gammaArray/max(gammaArray));
   t1 = t1 + distTime;
   t2 = t2 + deltatime;
    gapArray(K) = maxg;
end
runtime = 2*t1/cK + t2;
[maxV,optK] = max(gapArray);

if cK > 10%%Avoid Avoid falling into smaller clusters when the number of clusters is large on noise data
    counts = zeros(1,cK);
    ratios = zeros(1,cK);
    for i = optK+1:cK-1
        tempArrayi = gapArray(i) - gapArray((i+1):cK);
        if isempty(find(tempArrayi < 0)) %#ok<EFIND>
            counts(i) = length(tempArrayi);
            ratios(i) = sum(gapArray((i+1):cK))/sum(gapArray);
        end
    end
    
    [~,maxK] = max(counts);
    if (maxK > optK +1) && (gapArray(maxK) > 0.1*maxV)
        optK = maxK;
        maxV = gapArray(optK);
    end
end

end

