function [centerIndexes,cluIndexes] = DensityBasedSpectralClustering(vN, K)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
N = size(vN,2);
kerN = vN(:,N-K+1:N-1);
normN = sum(kerN .^2, 2) .^.5;
kerNS = bsxfun(@rdivide, kerN, normN + eps);

distMatrix = squareform(pdist(kerNS))+eps;
rhoArray = zeros(N,1);
% M = ceil(log(N));
M = ceil(sqrt(N));

for i = 1:N
    %M = sum(W(:,i)~=0);
    sortValues = sort(distMatrix(i,:));
    rhoArray(i) = M./mean(sortValues([2:(M+1)]));
       %rhoArray(i) = exp(-(mean(sortValues([1:(M+1)])))^2/M);
end
%rhoArray
maxd=max(max(distMatrix));
[~,ordrho]=sort(rhoArray,'descend');
deltaArray = zeros(N,1);
NNArray = zeros(N,1);
deltaArray(ordrho(1))=-1;
NNArray(ordrho(1))=ordrho(1);

for ii=2:N
   deltaArray(ordrho(ii))=maxd;
   for jj=1:ii-1
     if(distMatrix(ordrho(ii),ordrho(jj))<deltaArray(ordrho(ii)))
        deltaArray(ordrho(ii))=distMatrix(ordrho(ii),ordrho(jj));
        %NNArray(ordrho(ii))=ordrho(jj);
     end
   end
end

deltaArray(ordrho(1))=max(deltaArray(:));

gamaArray = rhoArray.*deltaArray;
[~,sInds] = sort(gamaArray, 'descend');
centerIndexes = sInds([1:K]);

cluIndexes = zeros(N,1) - 1;
for i = 1:numel(centerIndexes)
    cluIndexes(centerIndexes(i)) = i;
end

for ii=2:N
   idxes = ordrho(1:(ii-1));
   idii =  ordrho(ii);
  % isexist = find(idii,centerIndexes);
  if cluIndexes(idii) < 0
   distArrayii = distMatrix(idii,idxes);
   [~,minIdx] = min(distArrayii);
   NNArray(idii) = idxes(minIdx);
  end
end


[cluIndexes] = CluteringBasedOnCenter(rhoArray, NNArray, centerIndexes);

end

