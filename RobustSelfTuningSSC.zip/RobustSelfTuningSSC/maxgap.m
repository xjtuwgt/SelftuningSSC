function [maxg] = maxgap(varray, K )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
N = length(varray);
svarray = sort(varray,'descend');
svarray = svarray./(svarray(1)+eps);

gaps = svarray(1:N-1)-svarray(2:N);
 
 if K == 2%The second maximum gap is special in practice
     [maxgap, maxIndex] = max(gaps);
     maxg = gaps(K)/(maxIndex);
     return;
 end
maxg = gaps(K);
end

